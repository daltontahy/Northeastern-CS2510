import tester.*;                
// The tester library
import javalib.worldimages.*;   
// images, like RectangleImage or OverlayImages
import javalib.funworld.*;
// the abstract World class and the big-bang library
import java.awt.Color;          
// general colors (as triples of red,green,blue values)
// and predefined colors (Red, Green, Yellow, Blue, Black, White)
import javalib.worldcanvas.WorldCanvas;
import java.util.Random;

//check:
//templates, purposes, method templates, tests
//utils done
//ILoword done
//IWord done


//represents a list of words
interface ILoWord {
  
  //takes in a string of length 1 and produces a list of words by removing the 
  // first letter of any *active* words in the list who matches the given string
  ILoWord checkAndReduce(String s);
  
  //takes in an IWord and adds that IWord to the end of the ILoWord
  ILoWord addToEnd(IWord w);
  
  //Takes in an ILoWord and removes all empty strings
  ILoWord filterOutEmpties();
  
  //Takes in a worldscene draws all of the ILoWords onto the worldscene
  WorldScene draw(WorldScene ws);
  
  //skips the first word and checks the rest
  ILoWord skipLoWordCheckEmpty();
  
  //returns true if there is a word that has reached the bottom of the screen 
  //(will always be whether the first word has since first word will be lowest)
  boolean checkGameOver(int worldHeight);
  
  //returns a list of words but all the words have their y coordinates moved down
  ILoWord move();
  
  //returns the number of active words in the list
  int getAllActive();
  
  //returns a list of words with an inactive word activated if key matches
  ILoWord activate(String key);
  
}

//represents an empty list of words
class MtLoWord implements ILoWord {
  
  /* Template:
   * Fields:
   *... this.first ... -- IWord
   *... this.rest ... -- ILoWord
   *
   * Methods:
   * this.checkAndReduce(String S) -- ILoWord
   * this.addToEnd(IWord w) -- ILoWord
   * this.filterOutEmpties() -- ILoWord
   * this.draw(WorldScene ws) -- WorldScene
   * this.skipLoWordCheckEmpty() -- ILoWord
   * boolean checkGameOver(int worldHeight) -- boolean
   * ILoWord move() -- ILoWord
   * int getAllActive() -- int
   * ILoWord activate(String key) -- ILoWord
   * 
   * Methods of fields:
   * n/a
   */

  //takes in a string of length 1 and produces a list of words by removing the 
  // first letter of any *active* words in the list who matches the given string
  public ILoWord checkAndReduce(String s) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return this;
  }

  //takes in an IWord and adds that IWord to the end of the ILoWord
  public ILoWord addToEnd(IWord w) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    *... w.checkEmpty() ... -- boolean
    *... w.returnReduce(String s) ... -- String
    *... w.reduce(String s) ... -- String
    *... w.toImage(WorldScene ws) ... -- WorldScene
    *... w.isActive() ... -- int
    *... w.activateWord(String key, ILoWord rest) ... -- ILoWord
    *... w.checkHeight(int worldHeight) ... -- boolean
    *... w.moveWord() ... -- IWord
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return new ConsLoWord(w, this);
  }

  //Takes in an ILoWord and removes all empty strings
  public ILoWord filterOutEmpties() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return this;
  }

  //Takes in a worldscene draws all of the ILoWords onto the worldscene
  public WorldScene draw(WorldScene ws) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return ws;
  }

  //skips the first word and checks the rest
  public ILoWord skipLoWordCheckEmpty() {
    // TODO Auto-generated method stub
    return this;
  }  
  
  //returns true if there is a word that has reached the bottom of the screen 
  //(will always be whether the first word has since first word will be lowest)
  public boolean checkGameOver(int worldHeight) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    n/a
    ---------------------------------------------------*/
    return false;
  }
  
  //returns a list of words but all the words have their y coordinates moved down
  public ILoWord move() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    n/a
    ---------------------------------------------------*/
    return this;
  }
  
  //returns the number of active words in the list
  public int getAllActive() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    n/a
    ---------------------------------------------------*/
    return 0;
  }
  
  //returns a list of words with an inactive word activated if key matches
  public ILoWord activate(String key) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    n/a
    ---------------------------------------------------*/
    return this;
  }
  
}

class ConsLoWord implements ILoWord {
  IWord first;
  ILoWord rest;
  
  /* Template:
   * Fields:
   *... this.first ... -- IWord
   *... this.rest ... -- ILoWord
   *
   * Methods:
   * this.checkAndReduce(String S) -- ILoWord
   * this.addToEnd(IWord w) -- ILoWord
   * this.filterOutEmpties() -- ILoWord
   * this.draw(WorldScene ws) -- WorldScene
   * this.skipLoWordCheckEmpty() -- ILoWord
   * boolean checkGameOver(int worldHeight) -- boolean
   * ILoWord move() -- ILoWord
   * int getAllActive() -- int
   * ILoWord activate(String key) -- ILoWord
   * 
   * Methods of fields:
   * rest.checkAndReduce(String S) -- ILoWord
   * rest.addToEnd(IWord w) -- ILoWord
   * rest.filterOutEmpties() -- ILoWord
   * rest.skipLoWordCheckEmpty() -- ILoWord
   * rest.boolean checkGameOver(int worldHeight) -- boolean
   * rest.ILoWord move() -- ILoWord
   * rest.int getAllActive() -- int
   * rest.ILoWord activate(String key) -- ILoWord
   * first.checkEmpty() -- boolean
   * first.returnReduce(String s) -- String
   * first.reduce(String s) -- String
   * first.compareWords(IWord comparePrevious) -- String
   * first.compareStringsHelper(IWord nextWord, String next) -- boolean
   * first.toImage(WorldScene ws) -- WorldScene
   * first.isActive() -- int
   * first.activateWord(String key, ILoWord rest) -- ILoWord
   */

  ConsLoWord(IWord first, ILoWord rest) {
    this.first = first;
    this.rest = rest;
  }

  //takes in a string of length 1 and produces a list of words by removing the 
  // first letter of any *active* words in the list who matches the given string
  public ILoWord checkAndReduce(String s) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return new ConsLoWord(this.first.returnReduce(s), this.rest.checkAndReduce(s));
  }

  //takes in an IWord and adds that IWord to the end of the ILoWord
  public ILoWord addToEnd(IWord w) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    *... w.checkEmpty() ... -- boolean
    *... w.returnReduce(String s) ... -- String
    *... w.reduce(String s) ... -- String
    *... w.toImage(WorldScene ws) ... -- WorldScene
    *... w.isActive() ... -- int
    *... w.activateWord(String key, ILoWord rest) ... -- ILoWord
    *... w.checkHeight(int worldHeight) ... -- boolean
    *... w.moveWord() ... -- IWord
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return new ConsLoWord(this.first, this.rest.addToEnd(w));
  }

  //Takes in an ILoWord and removes all empty strings
  public ILoWord filterOutEmpties() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    if (this.first.checkEmpty()) {
      return this.rest.skipLoWordCheckEmpty();
    } else {
      return new ConsLoWord(this.first, this.rest.filterOutEmpties());
    }
  }

  //Takes in a worldscene draws all of the ILoWords onto the worldscene
  public WorldScene draw(WorldScene ws) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    ---------------------------------------------------*/
    return this.first.toImage(this.rest.draw(ws));
  }

  //skips the first word and checks the rest
  public ILoWord skipLoWordCheckEmpty() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    if (this.first.checkEmpty()) {
      return this.rest.skipLoWordCheckEmpty();
    } else {
      return new ConsLoWord(this.first, this.rest.filterOutEmpties());
    }
  }
 
  //returns true if there is a word that has reached the bottom of the screen 
  //(will always be whether the first word has since first word will be lowest)
  public boolean checkGameOver(int worldHeight) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return this.first.checkHeight(worldHeight);
  }
  
  //returns a list of words but all the words have their y coordinates moved down
  public ILoWord move() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new ConsLoWord(this.first.moveWord(), this.rest.move());
  }
  
  //returns the number of active words in the list
  public int getAllActive() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return this.first.isActive() + this.rest.getAllActive();
  }
  
  //returns a list of words with an inactive word activated if key matches
  public ILoWord activate(String key) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return this.first.activateWord(key, this.rest);
  }
  
}








//represents a word in the ZType game
interface IWord {
  
  //check if word is empty String
  boolean checkEmpty();
  
  //get the reduced (if needed) word
  IWord returnReduce(String s);
  
  //reduce the word if needed
  String reduce(String s);
  
  //returns a world scene with the word added
  WorldScene toImage(WorldScene ws);
  
  //returns true if there is the word that has reached the bottom of the screen
  boolean checkHeight(int worldHeight);
  
  //returns a new word with the y coordinate moved down
  IWord moveWord();
  
  //returns 1 if the word is active, 0 if not
  int isActive();
  
  // returns an active word if the key matches the first letter
  ILoWord activateWord(String key, ILoWord rest);
 
}

//represents an active word in the ZType game
class ActiveWord implements IWord {
  String word;
  int x;
  int y;
  
  /* Template:
   * Fields:
   *... this.word ... -- String
   *... this.x ... -- int
   *... this.y ... -- int
   * Methods:
   *... this.checkEmpty() ... -- boolean
   *... this.returnReduce(String s) ... -- String
   *... this.reduce(String s) ... -- String
   *... this.toImage(WorldScene ws) ... -- WorldScene
   *... this.checkHeight(int worldHeight) ... -- boolean
   *... this.moveWord() ... -- IWord
   *... this.isActive() ... -- int
   *... this.activateWord(String key, ILoWord rest) ... -- ILoWord
   * Methods of fields:
   * n/a
   */
  

  ActiveWord(String word, int x, int y) {
    this.word = word;
    this.x = x;
    this.y = y;
  }

  //check if word is empty String
  public boolean checkEmpty() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return this.word.isEmpty();
  }
  
  //get the reduced (if needed) word
  public IWord returnReduce(String s) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return new ActiveWord(reduce(s), this.x, this.y);
  }

  //reduce the word if needed
  public String reduce(String s) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    if (!this.word.isEmpty()
        && this.word.toLowerCase().substring(0,1).equals(s.toLowerCase())) {
      return this.word.substring(1); 
    } else {
      return this.word;
    }
  }
  
  //returns a world scene with the word added
  public WorldScene toImage(WorldScene ws) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    ---------------------------------------------------*/
    return ws.placeImageXY(
        new TextImage(this.word, Color.CYAN), this.x, this.y);
  }

  //returns true if there is the word that has reached the bottom of the screen
  public boolean checkHeight(int worldHeight) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return this.y > worldHeight;
  }
  
  //returns a new word with the y coordinate moved down
  public IWord moveWord() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new ActiveWord(this.word, this.x, this.y + 1);
  }
  
  //returns 1 if the word is active, 0 if not
  public int isActive() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return 1;
  }
  
  // returns an active word if the key matches the first letter only if inactive
  public ILoWord activateWord(String key, ILoWord rest) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
     * rest.checkAndReduce(String S) -- ILoWord
     * rest.addToEnd(IWord w) -- ILoWord
     * rest.filterOutEmpties() -- ILoWord
     * rest.skipLoWordCheckEmpty() -- ILoWord
     * rest.boolean checkGameOver(int worldHeight) -- boolean
     * rest.ILoWord move() -- ILoWord
     * rest.int getAllActive() -- int
     * rest.ILoWord activate(String key) -- ILoWord
    ---------------------------------------------------*/
    return new ConsLoWord(this, rest.activate(key));
  }
  
  
}

//represents an inactive word in the ZType game
class InactiveWord implements IWord {
  String word;
  int x;
  int y;

  /* Template:
   * Fields:
   *... this.word ... -- String
   *... this.x ... -- int
   *... this.y ... -- int
   * Methods:
   *... this.checkEmpty() ... -- boolean
   *... this.returnReduce(String s) ... -- String
   *... this.reduce(String s) ... -- String
   *... this.toImage(WorldScene ws) ... -- WorldScene
   *... this.checkHeight(int worldHeight) ... -- boolean
   *... this.moveWord() ... -- IWord
   *... this.isActive() ... -- int
   *... this.activateWord(String key, ILoWord rest) ... -- ILoWord
   * Methods of fields:
   * n/a
   */

  InactiveWord(String word, int x, int y) {
    this.word = word;
    this.x = x;
    this.y = y;
  }

  //check if word is empty String
  public boolean checkEmpty() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return this.word.isEmpty();
  }

  //get the reduced (if needed) word
  public IWord returnReduce(String s) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return this;
  }

  //reduce the word if needed
  public String reduce(String s) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    // TODO Auto-generated method stub
    return this.word;
  }

  //returns a world scene with the word added
  public WorldScene toImage(WorldScene ws) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
    ---------------------------------------------------*/
    return ws.placeImageXY(
        new TextImage(this.word, Color.RED), this.x, this.y);
  }
  
  //returns true if there is the word that has reached the bottom of the screen
  public boolean checkHeight(int worldHeight) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return this.y > worldHeight;
  }
  
  //returns a new word with the y coordinate moved down
  public IWord moveWord() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new InactiveWord(this.word, this.x, this.y + 1);
  }
  
  //returns 0 if the word is inactive, 0 if not
  public int isActive() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return 0;
  }
  
  // returns an active word if the key matches the first letter only if inactive
  public ILoWord activateWord(String key, ILoWord rest) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
     * rest.checkAndReduce(String S) -- ILoWord
     * rest.addToEnd(IWord w) -- ILoWord
     * rest.filterOutEmpties() -- ILoWord
     * rest.skipLoWordCheckEmpty() -- ILoWord
     * rest.boolean checkGameOver(int worldHeight) -- boolean
     * rest.ILoWord move() -- ILoWord
     * rest.int getAllActive() -- int
     * rest.ILoWord activate(String key) -- ILoWord
    ---------------------------------------------------*/
    if (this.word.toLowerCase().substring(0, 1).equals(key.toLowerCase())) {
      return new ConsLoWord(new ActiveWord(this.word, this.x, this.y),
          rest);
    } else {
      return new ConsLoWord(this, rest.activate(key));
    }
  }
  
}







//represents the ZType game world
interface IZTypeWorld {
  int WORLD_HEIGHT = 500;
  int WORLD_WIDTH = 500;
  //represents a ship image
  WorldImage OLDSHIP = new OverlayImage(
      new RectangleImage(30, 60, OutlineMode.SOLID, Color.GRAY),
      new EllipseImage(60, 30, OutlineMode.SOLID, Color.WHITE));
  
  WorldImage SHIP = new ScaleImage(new FromFileImage("R.png"), 0.1);
  
  //represents a space background
  WorldScene BACKGROUND = 
      new WorldScene(IZTypeWorld.WORLD_WIDTH, IZTypeWorld.WORLD_HEIGHT)
      .placeImageXY(
          new RectangleImage(IZTypeWorld.WORLD_WIDTH, IZTypeWorld.WORLD_HEIGHT, 
              OutlineMode.SOLID, Color.BLACK), 
          IZTypeWorld.WORLD_WIDTH / 2, IZTypeWorld.WORLD_HEIGHT / 2)
      .placeImageXY(
          new CircleImage(2, OutlineMode.SOLID, Color.WHITE), 
          IZTypeWorld.WORLD_WIDTH / 3, IZTypeWorld.WORLD_HEIGHT * 16 / 18)
      .placeImageXY(
          new CircleImage(2, OutlineMode.SOLID, Color.WHITE), 
          IZTypeWorld.WORLD_WIDTH / 2, IZTypeWorld.WORLD_HEIGHT / 4)
      .placeImageXY(
          new CircleImage(2, OutlineMode.SOLID, Color.WHITE), 
          IZTypeWorld.WORLD_WIDTH * 12 / 15, IZTypeWorld.WORLD_HEIGHT / 2)
      .placeImageXY(
          new CircleImage(2, OutlineMode.SOLID, Color.WHITE), 
          IZTypeWorld.WORLD_WIDTH * 13 / 14, IZTypeWorld.WORLD_HEIGHT / 4)
      .placeImageXY(
          new CircleImage(2, OutlineMode.SOLID, Color.WHITE), 
          IZTypeWorld.WORLD_WIDTH / 9, IZTypeWorld.WORLD_HEIGHT * 13 / 16)
      .placeImageXY(
          new CircleImage(2, OutlineMode.SOLID, Color.WHITE), 
          IZTypeWorld.WORLD_WIDTH / 4, IZTypeWorld.WORLD_HEIGHT * 4 / 7)
      .placeImageXY(
          new CircleImage(2, OutlineMode.SOLID, Color.WHITE), 
          IZTypeWorld.WORLD_WIDTH * 7 /  8, IZTypeWorld.WORLD_HEIGHT * 19 / 20);
  
  //represents a startup scene
  WorldScene STARTUP = IZTypeWorld.BACKGROUND.placeImageXY(
      new TextImage("Press ENTER to begin, or press P for options", 
          Color.WHITE), IZTypeWorld.WORLD_WIDTH / 2, IZTypeWorld.WORLD_HEIGHT / 2);
  
  //represents a options scene
  WorldScene OPTIONS = IZTypeWorld.BACKGROUND.placeImageXY(
      new TextImage("Press 1 for 6 Letter Words, 2 for Random Length Words", 
          Color.WHITE), IZTypeWorld.WORLD_WIDTH / 2, IZTypeWorld.WORLD_HEIGHT / 2);
  
  //represents a laser image and animation
  WorldImage LASER = new OverlayOffsetImage(
      new RectangleImage(5, Math.min(15, 0), OutlineMode.SOLID, Color.GREEN), 0, 5,
      new StarImage(5, OutlineMode.SOLID, Color.GREEN));
  
  WorldScene makeScene();
}

//represents the ZType game world
class ZTypeWorld extends World implements IZTypeWorld {
  ILoWord words;
  WorldScene ws;
  Random rand;
  int ticks;
  WorldScene worldScene;
  boolean sixOrRandom; //false if random, true if 6
  
  /* Template
   * Fields:
   * ... this.words ... -- ILoWord
   * ... this.ws ... -- WorldScene
   * ... this.rand ... -- Random
   * ... this.ticks ... -- int
   * ... this.worldScene ... -- WorldScene
   * ... this.sixOrRandom ... -- boolean
   * 
   * Methods:
   * ... this.makeScene() ... -- WorldScene
   * ... this.createSix() ... -- String
   * ... this.createX() ... -- int
   * ... this.onTick() ... -- World
   * ... this.lastScene(String s) ... -- WorldScene
   * ... this.onSpawn(int ticks) ... -- IWord
   * ... this.onKeyEvent(String key) ... -- ZTypeWorld
   * ... this.laserShot(WorldScene curWS, int tickSince) ... -- WorldScene
   * ... this.laser(int tickSince) ... -- WorldImage
   * ... this.score(int currTick, WorldScene oldws) ... -- WorldImage
   * ... this.levelSystem(int tick) ... -- int
   * ... this.createRandom() ... -- String
   * 
   * Methods of fields:
   * ... this.words.sort() ... -- ILoWord
   * ... this.words.isSorted() ... -- boolean
   * ... this.words.checkAndReduce(String s) ... -- ILoWord
   * ... this.words.addToEnd(IWord w) ... -- ILoWord
   * ... this.words.filterOutEmpties() ... -- ILoWord
   * ... this.words.insert(IWord compareFirst) ... -- ILoWord
   * ... this.words.draw(WorldScene ws) ... -- WorldScene
   * ... this.words.skipLoWordCheckEmpty() ... -- ILoWord
   * ... this.words.checkGameOver(int worldHeight) ... -- boolean
   * ... this.words.move() ... -- ILoWord
   * ... this.words.getAllActive() ... -- int
   * ... this.words.activate(String key) ... -- ILoWord
   */


  //for 'real' randoms
  ZTypeWorld(ILoWord words) {
    this.words = words;
    this.ws = IZTypeWorld.BACKGROUND;
    this.rand = new Random();
    this.ticks = 0;
    this.sixOrRandom = true;
  }
  
  //For testing (specified randoms)
  ZTypeWorld(ILoWord words, Random rand, int ticks, boolean sixOrRandom) {
    this.words = words;
    //this.ws = new WorldScene(IZTypeWorld.WORLD_WIDTH, IZTypeWorld.WORLD_HEIGHT);
    this.ws = IZTypeWorld.BACKGROUND.placeImageXY(IZTypeWorld.SHIP, 
        IZTypeWorld.WORLD_WIDTH / 2 , 
        IZTypeWorld.WORLD_HEIGHT * 36 / 40 + (ticks % 3));
    this.rand = rand;
    this.ticks = ticks;
    this.sixOrRandom = sixOrRandom;
  }
  
  //For ending scenes (specified ws)
  ZTypeWorld(ILoWord words, Random rand, int ticks, 
      WorldScene worldScene, boolean sixOrRandom) {
    this.words = words;
    this.ws = worldScene;
    this.rand = rand;
    this.ticks = ticks;
    this.sixOrRandom = sixOrRandom;
  }

  //draw the world with a list of words
  public WorldScene makeScene() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return this.words.draw(this.ws).placeImageXY(this.scoreLevel(this.ticks, this.ws),
        IZTypeWorld.WORLD_WIDTH * 3 / 20, 
        IZTypeWorld.WORLD_HEIGHT * 17 / 20);
  }
  
  //returns a random 6 letter word
  public String createSix() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new Utils().getSixLetterWord(rand);
  }
  
  //returns a random 6 letter word
  public String createRandom() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    if (this.sixOrRandom) {
      return this.createSix();
    } else {
      return new Utils().getRandomLetterWord(rand);
    }
  }

  //returns a random x coordinate
  public int createX() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new Utils().randomX(rand);
  }
  
  //returns a new world on every tick with the words moved down
  public World onTick() {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    if (this.words.checkGameOver(IZTypeWorld.WORLD_HEIGHT)) {
      return this.endOfWorld("Game Over");
    } else {
      return new ZTypeWorld(this.words.filterOutEmpties()
          .addToEnd(onSpawn(ticks)).move(), 
          this.rand, this.ticks + 1, this.sixOrRandom);
    }
  }
  
  //returns the final worldscene with a game over message
  public WorldScene lastScene(String s) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new WorldScene(IZTypeWorld.WORLD_WIDTH, IZTypeWorld.WORLD_HEIGHT)
        .placeImageXY(new RectangleImage(500, 500, "solid", Color.BLACK), 250, 250)
        .placeImageXY(new TextImage(s, Color.RED), 250, 250);
  }
  
  //returns a new word on every 15th tick
  public IWord onSpawn(int tick) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    //System.out.println(tick);
    //System.out.println(tick % levelSystem(tick) == 0);
    if (tick % levelSystem(tick) == 0) {
      return new InactiveWord(createRandom(), createX(), 0);
    } else {
      return new InactiveWord("", 0, 0);
    }
  }

  //returns a new world with the words checked and reduced based on key input
  public ZTypeWorld onKeyEvent(String key) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    if (key.equals("enter")) {
      return new ZTypeWorld(new MtLoWord());
    } else if (this.words.getAllActive() == 0) {
      return new ZTypeWorld(
          this.words.filterOutEmpties().activate(key).checkAndReduce(key), 
          this.rand, this.ticks, laserShot(this.ws, 0), this.sixOrRandom);
    } else {
      return new ZTypeWorld(this.words.checkAndReduce(key), this.rand, 
          this.ticks, laserShot(this.ws, 0), this.sixOrRandom);
    }
  }

  
  
  
  //represents a shooting a laser
  public WorldScene laserShot(WorldScene curWS, int tickSince) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return curWS.placeImageXY(laser(tickSince), 
        IZTypeWorld.WORLD_WIDTH / 2 + tickSince, 400 + tickSince);
  }
  
  //represents a laser image and animation
  public WorldImage laser(int tickSince) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new OverlayOffsetImage(
        new RectangleImage(5, Math.min(15, tickSince), OutlineMode.SOLID, Color.GREEN), 0, 5,
        new StarImage(5, OutlineMode.SOLID, Color.GREEN));
  }
  
  //represents a shooting a laser
  public WorldImage scoreLevel(int currTick, WorldScene oldws) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return new AboveImage(new TextImage("Score: " + currTick / 10, Color.WHITE),
        new TextImage("Level: " + Math.abs(30 - levelSystem(currTick)), Color.WHITE));
  }
  
  //increases the speed of spawning
  public int levelSystem(int tick) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    if (tick / 50 == 0) {
      return 30;
    } else {
      //System.out.println(30 - ticks / 50);
      return Math.max(5, 31 - tick / 50);
    }
  }
      
  
  
}

//utility interface for ZType
interface IUtils {
  String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
}

//utility class for ZType
class Utils implements IUtils {
  /* TEMPALTE
   * Fields:
   * n/a
   * Methods:
   * ... this.getSixLetterWord(Random rand) ... -- String
   * ... this.getSixLetterWordHelp(Random rand, int currNum, String wordAcc) ... -- String
   * ... this.randomX(Random rand) ... -- int
   * ... this.getRandomLetterWord(Random rand) ... -- String
   * ... this.getRandomLetterWordHelp(Random rand, int currNum, 
   * String wordAcc, int randomLength) ... -- String
   * Methods of fields:
   * n/a
   */
  
  Utils() { }
  
  //returns a random 6 letter word
  String getSixLetterWord(Random rand) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return getSixLetterWordHelp(rand, rand.nextInt(25), "");
  }
  
  //helps returns a random 6 letter word
  String getSixLetterWordHelp(Random rand, int currNum, String wordAcc) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    if (wordAcc.length() == 6) {
      return wordAcc;
    } else {
      return getSixLetterWordHelp(rand, rand.nextInt(25), 
          wordAcc + IUtils.ALPHABET.substring(currNum, currNum + 1));
    }
  }
  
  //returns a random word of random length
  String getRandomLetterWord(Random rand) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return getRandomLetterWordHelp(rand, rand.nextInt(25), "", rand.nextInt(4) + 3);
  }
  
  //helps returns a random word of random length
  String getRandomLetterWordHelp(Random rand, int currNum, String wordAcc, int randomLength) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    if (wordAcc.length() == randomLength) {
      return wordAcc;
    } else {
      return getRandomLetterWordHelp(rand, rand.nextInt(25), 
          wordAcc + IUtils.ALPHABET.substring(currNum, currNum + 1), randomLength);
    }
  }
  
  //returns a random x coordinate
  int randomX(Random rand) {
    /*---------------------------------------------------
    // TEMPLATE for this method:
    // EVERYTHING from our class-wide template...
    // PLUS methods on the parameters
       n/a
    ---------------------------------------------------*/
    return rand.nextInt(IZTypeWorld.WORLD_WIDTH * 17 / 20) + 50;
  }
  
  
}


















//all examples and tests for ILoWord
class ExamplesWordLists {
  IWord at = new ActiveWord("at", 0, 0);
  IWord be = new ActiveWord("Be", 100, 200);
  IWord cat = new ActiveWord("cAt", 0, 0);
  IWord dam = new InactiveWord("dam", 0, 0);
  IWord dot = new ActiveWord("dot", 0, 0);
  IWord all = new InactiveWord("All", 0, 0);
  //empty IWord
  IWord emptyW = new ActiveWord("", 0, 0);
  IWord emptyIW = new InactiveWord("", 0, 0);
  
  //empty
  ILoWord emptyL = new MtLoWord();
  //sorted list
  ILoWord sL1 = new ConsLoWord(be, emptyL);
  ILoWord sL2 = new ConsLoWord(at, sL1);
  //unsorted list
  ILoWord uL1 = new ConsLoWord(cat, emptyL);
  ILoWord uL2 = new ConsLoWord(dam, uL1);
  ILoWord uL3 = new ConsLoWord(dot, uL2);
  //different sized list
  ILoWord dSL1 = new ConsLoWord(dam, new ConsLoWord(all, 
      new ConsLoWord(be, new ConsLoWord(at, emptyL))));
  ILoWord dSL2 = new ConsLoWord(all, new ConsLoWord(at, 
      new ConsLoWord(be, new ConsLoWord(dam, emptyL))));
  
  //repeat sorted and unsorted
  ILoWord rSL1 = new ConsLoWord(all, sL2);
  ILoWord rUSL1 = new ConsLoWord(at, rSL1);
  ILoWord rSL2 = new ConsLoWord(at, sL2);
  ILoWord rSL3 = new ConsLoWord(at, rSL1);
  
  //emptyCons
  ILoWord emptyWL1 = new ConsLoWord(emptyW, emptyL);
  ILoWord emptyWL2 = new ConsLoWord(emptyIW, emptyL);
  //with empty strings
  ILoWord eSDSL1 = new ConsLoWord(dam, new ConsLoWord(emptyW, 
      new ConsLoWord(all, new ConsLoWord(be, new ConsLoWord(at, emptyL)))));
  ILoWord eSL1 = new ConsLoWord(at, new ConsLoWord(emptyW, sL1));
  ILoWord eSL2 = new ConsLoWord(emptyW, new ConsLoWord(at, sL1));
  //at, "", be, emptyL
  ILoWord eUSL2 = new ConsLoWord(emptyIW, new ConsLoWord(at, sL1));
  ILoWord eRUSL1 = new ConsLoWord(at, new ConsLoWord(emptyW, rSL1));
  ILoWord eRUSL2 = new ConsLoWord(emptyIW, new ConsLoWord(at, 
      new ConsLoWord(emptyW, rSL1)));
  
  WorldScene worldscene = new WorldScene(500,500);
  WorldCanvas worldcanvas = new WorldCanvas(500,500);
  
  ZTypeWorld ztypeEM = new ZTypeWorld(emptyL, new Random(0), 0, true);
  Utils utils = new Utils();
  Random rand = new Random(0);

  //tests whether checkAndReduce properly reduces only active word in a 
  // list of words with the given string
  boolean testCheckAndReduce(Tester t) {
    return t.checkExpect(this.emptyL.checkAndReduce("a"), this.emptyL) 
        //test empty list
        && t.checkExpect(this.sL2.checkAndReduce("p"), this.sL2) 
        //tests basic func. non first letter, list of two
        && t.checkExpect(this.sL2.checkAndReduce("a"), new ConsLoWord(
            new ActiveWord("t",0,0), this.sL1))
        //tests basic func. true first letter, list of two
        && t.checkExpect(this.sL1.checkAndReduce("a"), this.sL1)
        //tests basic func. non first letter, list of one
        && t.checkExpect(this.sL1.checkAndReduce("b"), new ConsLoWord(
            new ActiveWord("e",100,200), this.emptyL))
        //tests basic func. true first letter, list of one
        && t.checkExpect(this.uL2.checkAndReduce("c"), new ConsLoWord(this.dam, 
            new ConsLoWord(new ActiveWord("At",0,0), this.emptyL)))
        //tests basic func. true first letter, list of incative
        && t.checkExpect(this.uL2.checkAndReduce("d"), new ConsLoWord(this.dam, 
            new ConsLoWord(new ActiveWord("cAt",0,0), this.emptyL)))
        //tests basic func. true first letter two steps down, list of two
        && t.checkExpect(this.dSL1.checkAndReduce("a"), new ConsLoWord(this.dam, 
            new ConsLoWord(this.all, new ConsLoWord(this.be, 
                new ConsLoWord(new ActiveWord("t",0,0), this.emptyL)))))
        // test basic func. true first letter a ways down
        && t.checkExpect(this.eSDSL1.checkAndReduce(""), this.eSDSL1)
        // test basic func. empty word
        && t.checkExpect(this.rSL2.checkAndReduce("a"), new ConsLoWord(
            new ActiveWord("t",0,0), new ConsLoWord(
                new ActiveWord("t",0,0), this.sL1))); 
    // test basic func. repeats list
        
  }
  
  //tests whether addToEnd properly appends the given word to the list of words
  boolean testAddToEnd(Tester t) {
    return t.checkExpect(this.emptyL.addToEnd(this.emptyW), 
        new ConsLoWord(this.emptyW, this.emptyL)) 
        //tests empty list with empty word
        && t.checkExpect(this.emptyL.addToEnd(this.at), 
            new ConsLoWord(this.at, this.emptyL)) 
        //tests empty list with word
        && t.checkExpect(this.sL2.addToEnd(this.dot), new ConsLoWord(this.at, 
            new ConsLoWord(this.be, new ConsLoWord(this.dot, this.emptyL)))) 
        //tests basic func. sorted size 2
        && t.checkExpect(this.sL1.addToEnd(this.all), new ConsLoWord(this.be, 
            new ConsLoWord(this.all, this.emptyL))) 
        //tests basic func. sorted size 1
        && t.checkExpect(this.dSL1.addToEnd(this.cat), 
            new ConsLoWord(this.dam, new ConsLoWord(this.all, 
            new ConsLoWord(this.be, new ConsLoWord(this.at, 
                new ConsLoWord(this.cat, this.emptyL)))))) 
        //tests basic func. big unsorted
        && t.checkExpect(this.rSL2.addToEnd(this.at), new ConsLoWord(this.at, 
            new ConsLoWord(this.at, new ConsLoWord(this.be, 
                new ConsLoWord(this.at, this.emptyL))))); //tests basic func. repeats
  }
  
  //tests whether filterOutEmpties properly removes any IWords in a list of 
  //words with an empty string
  boolean testFilterOutEmpties(Tester t) {
    return t.checkExpect(this.emptyL.filterOutEmpties(), this.emptyL) 
        //tests empty list
        && t.checkExpect(this.sL2.filterOutEmpties(), this.sL2) 
        //tests basic func. sorted
        && t.checkExpect(this.sL1.filterOutEmpties(), this.sL1) 
        //tests basic func. sorted
        && t.checkExpect(this.uL2.filterOutEmpties(),this.uL2) 
        //tests basic func. unsorted
        && t.checkExpect(this.dSL1.filterOutEmpties(),this.dSL1) 
        //tests basic func. big unsorted
        && t.checkExpect(this.rSL1.filterOutEmpties(),this.rSL1) 
        //tests basic func. repeats
        && t.checkExpect(this.rUSL1.filterOutEmpties(),this.rUSL1) 
        //tests basic func. repeats unsorted
        && t.checkExpect(this.eSL1.filterOutEmpties(),this.sL2) 
        //tests basic func. list w/empty string
        && t.checkExpect(this.eRUSL1.filterOutEmpties(),this.rUSL1)
        //tests basic func. unsorted list w/empty string
        && t.checkExpect(this.eRUSL2.filterOutEmpties(),this.rUSL1)
        //tests basic func. unsorted list w/empty string
        && t.checkExpect(this.rSL2.filterOutEmpties(),this.rSL2);
    //tests basic func. list w/repeats
  }
  
  //tests whether draw properly creates a WorldScene
  boolean testDraw(Tester t) {
    return t.checkExpect(this.emptyL.draw(this.worldscene), this.worldscene)
        //draw empty scene
        && t.checkExpect(this.sL2.draw(this.worldscene), 
            new WorldScene(500,500).placeImageXY(
                new TextImage("Be", Color.CYAN), 100, 200).placeImageXY(
                    new TextImage("at", Color.CYAN), 0, 0))
        //basic draw list
        && t.checkExpect(this.uL2.draw(this.worldscene), 
            new WorldScene(500,500).placeImageXY(
                new TextImage("cAt", Color.CYAN), 0, 0).placeImageXY(
                    new TextImage("dam", Color.RED), 0, 0))
        //basic draw with overlap
        //below is basic draw with empty string in middle
        && t.checkExpect(this.eSL1.draw(this.worldscene), 
            new WorldScene(500,500).placeImageXY(
                new TextImage("Be", Color.CYAN), 100, 200).placeImageXY(
                new TextImage("", Color.CYAN), 0, 0).placeImageXY(
                    new TextImage("at", Color.CYAN), 0, 0));
  }
  
  //checks if skipLoWordCheckEmpty correctly removes empty strings
  boolean testSkipLoWordCheckEmpty(Tester t) {
    return t.checkExpect(this.sL2.skipLoWordCheckEmpty(), 
        this.sL2) // checks ordered size 2
        && t.checkExpect(this.sL1.skipLoWordCheckEmpty(), 
            this.sL1)//checks ordered size 1
        && t.checkExpect(this.uL2.skipLoWordCheckEmpty(), 
            this.uL2)//checks unordered
        && t.checkExpect(this.eSL1.skipLoWordCheckEmpty(), 
            this.sL2) //checks emptyString
        && t.checkExpect(this.emptyL.skipLoWordCheckEmpty(), 
            this.emptyL); //checks empty list
  }
  
  //tests the checkGameOver method
  boolean testCheckGameOver(Tester t) {
    return t.checkExpect(emptyL.checkGameOver(500), false) //tests empty list
        && t.checkExpect(sL2.checkGameOver(500), false) //tests basic list false
        && t.checkExpect(sL1.checkGameOver(10), true); //tests game over true
  }
  
  //tests the move method
  boolean testMove(Tester t) {
    return t.checkExpect(emptyL.move(), emptyL) //tests empty list
        && t.checkExpect(sL2.move(), new ConsLoWord(new ActiveWord("at", 0, 1), 
            new ConsLoWord(new ActiveWord("Be", 100, 201), emptyL)))
        //tests basic list all active
        && t.checkExpect(uL2.move(), new ConsLoWord(
            new InactiveWord("dam", 0, 1),
            new ConsLoWord(new ActiveWord("cAt", 0, 1),
                emptyL))); //tests basic list some active
  }
  
  //tests the getAllActive method
  boolean testGetAllActive(Tester t) {
    return t.checkExpect(emptyL.getAllActive(), 0) //tests empty list
        && t.checkExpect(sL2.getAllActive(), 2) //tests basic list all active
        && t.checkExpect(uL2.getAllActive(), 1); //tests basic list some active
  }
  
  //tests the activate method
  boolean testActivate(Tester t) {
    return t.checkExpect(emptyL.activate("s"), emptyL)//tests empty list
        && t.checkExpect(sL2.activate("s"), sL2) //tests already active
        && t.checkExpect(sL2.activate("a"), sL2)//tests already active
        && t.checkExpect(uL2.activate("s"), uL2) //tests inactive wrong key
        && t.checkExpect(uL2.activate("d"), 
            new ConsLoWord(new ActiveWord("dam", 0, 0), new ConsLoWord(
                new ActiveWord("cAt", 0, 0), emptyL)));//tests activating inactive
  }
  
  //tests draw such that it displays for dev purposes
  boolean xtestDrawDisplay(Tester t) {
    WorldScene s1 = new WorldScene(500, 500).placeImageXY(
        new RectangleImage(500, 500, "solid", Color.BLACK), 250, 250);
    return this.worldcanvas.drawScene(sL1.draw(s1)) && this.worldcanvas.show();
  }
  
  boolean testCheckEmpty(Tester t) {
    return t.checkExpect(this.at.checkEmpty(), false) 
        //tests if active word is empty
        && t.checkExpect(this.dam.checkEmpty(), false)
        //tests if inactive word is empty
        && t.checkExpect(this.emptyW.checkEmpty(), true);
    //tests if empty word is empty
  }
  
  //tests whether returnReduce returns an IWord thats reduced or not reduced
  // depending on activity
  boolean testReturnReduce(Tester t) {
    return t.checkExpect(this.at.reduce("s"), "at") //active, non match
        && t.checkExpect(this.at.reduce("a"), "t") //active, non match
        && t.checkExpect(this.at.reduce("t"), "at") //active, match
        && t.checkExpect(this.dam.reduce("d"), "dam");//inactive, match
  }
  
  //tests whether reduce returns a string that reduces by string it the word 
  //begins with that string and is an active word
  boolean testReduce(Tester t) {
    return t.checkExpect(this.at.returnReduce("s"), this.at) 
        //active, non match
        && t.checkExpect(this.at.returnReduce("a"), new ActiveWord("t", 0, 0))
        //active, match
        && t.checkExpect(this.at.returnReduce("t"), this.at)
        //active, non match
        && t.checkExpect(this.dam.returnReduce("d"), this.dam); //inactive, match
  }

  //tests whether toImage creates a correct worldscene
  boolean testToImage(Tester t) {
    return t.checkExpect(this.emptyW.toImage(this.worldscene), 
        this.worldscene.placeImageXY(
            new TextImage("", Color.CYAN), 0, 0)) //empty word
        && t.checkExpect(this.at.toImage(this.worldscene), 
            this.worldscene.placeImageXY(
                new TextImage("at", Color.CYAN), 0, 0)) //basic
        && t.checkExpect(this.dam.toImage(worldscene), 
            this.worldscene.placeImageXY(
                new TextImage("dam", Color.RED), 0, 0))
        && t.checkExpect(this.be.toImage(worldscene), 
            this.worldscene.placeImageXY(
                new TextImage("Be", Color.CYAN), 100, 200)); //dif. placement
  }
  
  //tests the checkHeight method
  boolean testCheckHeight(Tester t) {
    return t.checkExpect(this.emptyW.checkHeight(500), false) // empty
        && t.checkExpect(this.at.checkHeight(500), false) // basic false
        && t.checkExpect(this.be.checkHeight(10), true); // basic true
  }
  
  //tests the moveWord method
  boolean testMoveWord(Tester t) {
    return t.checkExpect(this.emptyW.moveWord(), 
        new ActiveWord("", 0, 1)) // empty
        && t.checkExpect(this.at.moveWord(), 
            new ActiveWord("at", 0, 1)) // basic
        && t.checkExpect(this.be.moveWord(), 
            new ActiveWord("Be", 100, 201)); // basic
  }
  
  //tests isActive method
  boolean testIsActive(Tester t) {
    return t.checkExpect(this.emptyW.isActive(), 1) // empty
        && t.checkExpect(this.at.isActive(), 1) // basic active
        && t.checkExpect(this.dam.isActive(), 0); // basic inactive
  }
  
  //tests activateWord method
  boolean testActivateWord(Tester t) {
    return t.checkExpect(this.emptyW.activateWord("s", emptyL), 
        new ConsLoWord(emptyW, emptyL))// empty
        && t.checkExpect(this.at.activateWord("s", emptyL),
            new ConsLoWord(at, emptyL)) // basic active
        && t.checkExpect(this.at.activateWord("a", sL1),
            sL2) // basic active into full rest
        && t.checkExpect(this.dam.activateWord("d", uL2), 
            new ConsLoWord(new ActiveWord("dam", 0, 0), uL2)) 
        //basic inactive only the first
        && t.checkExpect(this.dam.activateWord("d", emptyL),
            new ConsLoWord(new ActiveWord("dam", 0, 0), emptyL));//basic inactive
  }

  //tests the ztypeworld make scene
  boolean testMakeScene(Tester t) {
    //make scene empty
    return t.checkExpect(new ZTypeWorld(this.emptyL).makeScene(), 
        IZTypeWorld.BACKGROUND.placeImageXY(new AboveImage(
            new TextImage("Score: " + 0, Color.WHITE),
            new TextImage("Level: " + 0, Color.WHITE)), 75, 425))
        && t.checkExpect(new ZTypeWorld(this.sL2).makeScene(), 
            IZTypeWorld.BACKGROUND.placeImageXY(
                new TextImage("Be", Color.CYAN), 100, 200).placeImageXY(
                    new TextImage("at", Color.CYAN), 0, 0).placeImageXY(
                        new AboveImage(
                        new TextImage("Score: " + 0, Color.WHITE),
                        new TextImage("Level: " + 0, Color.WHITE)), 75, 425)) //basic draw
        && t.checkExpect(new ZTypeWorld(this.uL2).makeScene(), 
            IZTypeWorld.BACKGROUND.placeImageXY(
                new TextImage("cAt", Color.CYAN), 0, 0).placeImageXY(
                    new TextImage("dam", Color.RED), 0, 0).placeImageXY(
                        new AboveImage(
                        new TextImage("Score: " + 0, Color.WHITE),
                        new TextImage("Level: " + 0, Color.WHITE)), 75, 425)) 
        //basic draw with overlap
        && t.checkExpect(new ZTypeWorld(this.eSL1).makeScene(), 
            IZTypeWorld.BACKGROUND.placeImageXY(
                new TextImage("Be", Color.CYAN), 100, 200).placeImageXY(
                    new TextImage("", Color.CYAN), 0, 0).placeImageXY(
                        new TextImage("at", Color.CYAN), 0, 0).placeImageXY(
                            new AboveImage(
                            new TextImage("Score: " + 0, Color.WHITE),
                            new TextImage("Level: " + 0, Color.WHITE)), 75, 425));
    //basic draw with empty string
  }
  
  //tests the ztypeworld createSix method
  boolean testCreateSix(Tester t) {
    return t.checkExpect(ztypeEM.createSix(), "kxewpd") // basic random
        && t.checkExpect(new ZTypeWorld(this.emptyL, 
            new Random(5), 0, true).createSix(), "mryygf"); //basic random
  }
  
  //tests the ztypeworld createX method
  boolean testCreateX(Tester t) {
    return t.checkExpect(ztypeEM.createX(), 461) //basic random
        && t.checkExpect(new ZTypeWorld(this.emptyL, 
            new Random(5), 0, true).createX(), 412); //basic random
  }
  
  //tests the ztypeworld onTick method
  boolean testOnTick(Tester t) {
    return t.checkExpect(new ZTypeWorld(this.emptyL,
        new Random(0), 1, true).onTick(), 
        new ZTypeWorld(new ConsLoWord(new InactiveWord("", 0, 1), emptyL), 
            new Random(0), 2,
            IZTypeWorld.BACKGROUND.placeImageXY(IZTypeWorld.SHIP, 250, 452), 
            true))
        //empty spawn
        //below is new spawn
        && t.checkExpect(new ZTypeWorld(this.emptyL,
            new Random(0), 30, true)
            .onTick(), new ZTypeWorld(new ConsLoWord(
                new InactiveWord("kxewpd", 461, 1), emptyL), new Random(0), 31, 
                IZTypeWorld.BACKGROUND.placeImageXY(IZTypeWorld.SHIP, 250, 451), 
                true));
  }
  
  //tests the ztypeworld lastScene method
  boolean testLastScene(Tester t) {
    return t.checkExpect(new ZTypeWorld(this.emptyL,
        new Random(0), 0, true).lastScene("Game Over"), new WorldScene(500, 500)
        .placeImageXY(new RectangleImage(500, 500, 
            "solid", Color.BLACK), 250, 250)
        .placeImageXY(new TextImage("Game Over",
            Color.RED), 250, 250)) //basic game over
        && t.checkExpect(new ZTypeWorld(this.sL2,
            new Random(0), 0, true).lastScene("Game Over"), new WorldScene(500, 500)
            .placeImageXY(new RectangleImage(500, 500, 
                "solid", Color.BLACK), 250, 250)
            .placeImageXY(new TextImage("Game Over",
                Color.RED), 250, 250)); //basic game over
  }
  
  //tests the ztypeworld onSpawn method
  boolean testOnSpawn(Tester t) {
    return t.checkExpect(new ZTypeWorld(this.emptyL,
        new Random(0), 30, true).onSpawn(30), 
        new InactiveWord("kxewpd", 461, 0)) //spawn
        && t.checkExpect(new ZTypeWorld(this.emptyL,
            new Random(0), 1, true).onSpawn(1), 
            new InactiveWord("", 0, 0)); //no spawn
  }
  
  //tests the ztypeworld onKeyEvent method
  boolean testOnKeyEvent(Tester t) {
    return t.checkExpect(new ZTypeWorld(this.emptyL,
        new Random(0), 0, true).onKeyEvent("a"), 
        new ZTypeWorld(this.emptyL, new Random(0), 0, 
            IZTypeWorld.BACKGROUND.placeImageXY(
                IZTypeWorld.SHIP, 250, 450).placeImageXY(
                    IZTypeWorld.LASER, 250, 400), true)) //empty list
        && t.checkExpect(new ZTypeWorld(this.sL2,
            new Random(0), 0, true).onKeyEvent("a"), 
            new ZTypeWorld(new ConsLoWord(new ActiveWord("t", 0, 0), sL1), 
                new Random(0), 0, IZTypeWorld.BACKGROUND.placeImageXY(
                    IZTypeWorld.SHIP, 250, 450).placeImageXY(
                        IZTypeWorld.LASER, 250, 400), true)) 
        //basic reduce on already active
        && t.checkExpect(new ZTypeWorld(this.uL2,
            new Random(0), 0, true).onKeyEvent("a"), 
            new ZTypeWorld(this.uL2, new Random(0), 0, 
                IZTypeWorld.BACKGROUND.placeImageXY(
                IZTypeWorld.SHIP, 250, 450).placeImageXY(
                    IZTypeWorld.LASER, 250, 400), true)) //dont reduce no match
        && t.checkExpect(new ZTypeWorld(this.uL2,
            new Random(0), 0, true).onKeyEvent("d"), 
            new ZTypeWorld(uL2,
                new Random(0), 0, IZTypeWorld.BACKGROUND.placeImageXY(
                    IZTypeWorld.SHIP, 250, 450).placeImageXY(
                        IZTypeWorld.LASER, 250, 400), true)) 
        //dont reduce because 1 active
        && t.checkExpect(new ZTypeWorld(new ConsLoWord(this.dam, emptyL),
            new Random(0), 0, true).onKeyEvent("d"), 
            new ZTypeWorld(new ConsLoWord(new ActiveWord("am", 0, 0), emptyL),
                new Random(0), 0, IZTypeWorld.BACKGROUND.placeImageXY(
                    IZTypeWorld.SHIP, 250, 450).placeImageXY(
                        IZTypeWorld.LASER, 250, 400), true)); //basic reduce
  }

  //tests the ztypeworld laser method
  boolean testLaser(Tester t) {
    return t.checkExpect(this.ztypeEM.laser(0), new OverlayOffsetImage(
        new RectangleImage(5, 0, 
            OutlineMode.SOLID, Color.GREEN), 0, 5,
        new StarImage(5, OutlineMode.SOLID, Color.GREEN))) //basic laser tick 0
        && t.checkExpect(this.ztypeEM.laser(5), new OverlayOffsetImage(
                new RectangleImage(5, 5, 
                    OutlineMode.SOLID, Color.GREEN), 0, 5,
                new StarImage(5, OutlineMode.SOLID, Color.GREEN))); 
    //basic laser tick 5
  }
  
  //tests the ztypeworld laserShot method
  boolean testLaserShot(Tester t) {
    return t.checkExpect(this.ztypeEM.laserShot(worldscene, 0),
        worldscene.placeImageXY(new OverlayOffsetImage(
            new RectangleImage(5, 0, 
                OutlineMode.SOLID, Color.GREEN), 0, 5,
            new StarImage(5, OutlineMode.SOLID, Color.GREEN)), 250, 400))
        // basic laser start
        && t.checkExpect(this.ztypeEM.laserShot(worldscene, 5),
            worldscene.placeImageXY(new OverlayOffsetImage(
                new RectangleImage(5, 5, 
                    OutlineMode.SOLID, Color.GREEN), 0, 5,
                new StarImage(5, OutlineMode.SOLID, Color.GREEN)), 255, 405));
    // basic laser later on
  }
  
  //tests the ztypeworld scoreLevel method
  boolean testScoreLevel(Tester t) {
    return t.checkExpect(this.ztypeEM.scoreLevel(0, worldscene),
        new AboveImage(new TextImage("Score: " + 0, Color.WHITE), 
            new TextImage("Level: " + 0, Color.WHITE))) // basic start
        && t.checkExpect(this.ztypeEM.scoreLevel(10, worldscene),
            new AboveImage(new TextImage("Score: " + 1, Color.WHITE), 
                new TextImage("Level: " + 0, Color.WHITE))) //basic score
        && t.checkExpect(this.ztypeEM.scoreLevel(100, worldscene),
            new AboveImage(new TextImage("Score: " + 10, Color.WHITE), 
                new TextImage("Level: " + 1, Color.WHITE))); // basic level&score
  }
  
  //tests the ztypeworld levelSystem method
  boolean testLevelSystem(Tester t) {
    return t.checkExpect(this.ztypeEM.levelSystem(0), 30) // basic start
        && t.checkExpect(this.ztypeEM.levelSystem(50), 30); // basic later on
  }
  
  //tests the createRandom method
  boolean testCreateRandom(Tester t) {
    return t.checkExpect(
        new ZTypeWorld(emptyL, new Random(5), 0, false).createRandom(),
        "myy"); // basic
  }
  
  //tests the utils make six letter word; getSixLetterWord
  boolean testGetSixLetterWord(Tester t) {
    // Test generating a 6-letter word
    return t.checkExpect(utils.getSixLetterWord(new Random(1)), "knwnee")
        //test a different seed
        && t.checkExpect(utils.getSixLetterWord(new Random(5)), "mryygf");
  }

  //tests the utils make letter from random; getSixLetterWordHelp
  boolean testGetSixLetterWordHelp(Tester t) { 
    // Test generating a 6-letter word with the first letter 'a'
    return t.checkExpect(utils.getSixLetterWordHelp(
        new Random(1), 0, ""), "aknwne")
        // Test generating a 6-letter word with the first letter 'f'
        && t.checkExpect(utils.getSixLetterWordHelp(
            new Random(1), 5, ""), "fknwne")
        // Test generating a 6-letter word with the first letter 'z' (wrap-around)
        && t.checkExpect(utils.getSixLetterWordHelp(
            new Random(1), 25, ""), "zknwne");
  }
  
  //tests the utils make random length letter word; RandomSixLetterWord
  boolean testGetRandomLetterWord(Tester t) {
    // Test generating a 6-letter word
    return t.checkExpect(utils.getRandomLetterWord(new Random(1)), "kwn")
        //test a different seed
        && t.checkExpect(utils.getRandomLetterWord(new Random(5)), "myy");
  }
  
  //tests the utils make random length word from random; RandomSixLetterWordHelp
  boolean testGetRandomLetterWordHelp(Tester t) { 
    // Test generating a 6-letter word with the first letter 'a'
    return t.checkExpect(utils.getRandomLetterWordHelp(
        new Random(1), 0, "", 6), "aknwne")
        // Test generating a 6-letter word with the first letter 'f'
        && t.checkExpect(utils.getRandomLetterWordHelp(
            new Random(1), 5, "", 3), "fkn")
        // Test generating a 6-letter word with the first letter 'z' (wrap-around)
        && t.checkExpect(utils.getRandomLetterWordHelp(
            new Random(1), 25, "", 8), "zknwneej");
  }
  
  //tests the utils randomX method
  boolean testRandomX(Tester t) {
    // Test generating a random x value
    return t.checkExpect(utils.randomX(new Random(1)), 235)
        // Test generating a random x value
        && t.checkExpect(utils.randomX(new Random(5)), 412);
  }

}

//for starting the game
class ExamplesStartGame {
  //tests ztype such that it displays for dev purposes
  boolean testBigBang(Tester t) {
    double tickRate = 0.1; //seconds per frame
    return new ZTypeWorld(new MtLoWord(), new Random(), 0, false).bigBang(
        IZTypeWorld.WORLD_HEIGHT, IZTypeWorld.WORLD_HEIGHT, tickRate);
  }
  
  
}
